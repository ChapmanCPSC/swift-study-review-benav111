//
//  ViewController.swift
//  StudyHelper
//
//  Created by Matthew Luzar on 3/27/16.
//  Copyright © 2016 Matthew Luzar. All rights reserved.
//I made this on my sisters boyfriend's computer hence the matthew luzar part

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SubjectLabel: UILabel!
    @IBOutlet weak var TimerLabel: UILabel!
    @IBOutlet weak var NextButton: UIButton!
    var timer: NSTimer? = nil
    var countdownNumber = 30
    //array with all subjects
    var subjectArray: [String] = ["Let vs. Var", "Computed Initializers", "Computed Variables", "Setter Observers", "Functions", "External Parameters", "Default Parameters", "Anonymous Functions", "Optional Chaining", "Failable Initializers", "Casting", "Class Methods", "Extensions", "Enumeration", "Error Handling", "Dictionaries", "Conditional Binding", "Protocols", "Inheritance", "Structs", "Enums", "Classes", "Subscripts", "Setter Observers"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //set a timer
        timer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: Selector("updateTimer"),userInfo: nil, repeats: true)
        //start with the first item in array
        SubjectLabel.text = subjectArray[Int(arc4random_uniform(23))]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func updateTimer()  {
        if (countdownNumber > 0)
        {//if timer is greater than 0 keep decreasing
            TimerLabel.text = "00:" + String(countdownNumber--)
        }
        else if (countdownNumber == 0)
        {//if equal to zero reset to 30
        
            countdownNumber = 30
            SubjectLabel.text = subjectArray[Int(arc4random_uniform(23))]
            
        }
    }
    @IBAction func clickedNext(sender: AnyObject) {
        //method for when button is clicked
        countdownNumber = 30
        SubjectLabel.text = subjectArray[Int(arc4random_uniform(23))]
    }
    
}

